% This code is to check whether or not our attributes can be mid-level
% features for rating image aesthetics.

clear
close all
clc

%% load data
if exist('attMat.mat', 'file')
    load attMat.mat;
else
    attributeNames = {'score', 'BalacingElements', 'ColorHarmony', 'Content', 'DoF', 'Light', 'MotionBlur', 'Object', 'Repetition', 'RuleOfThirds',...
        'Symmetry', 'VividColor'};
    
    phaseNames = {'Train', 'TestNew', 'Validation'};
    
    dataset = cell(1,3);
    for phaseID = 1:length(phaseNames)
        fprintf('\nphase: %s', phaseNames{phaseID});
        filename = strcat( 'imgList', phaseNames{phaseID}, 'Regression_', attributeNames{1}, '.txt' );
        numImage = numel(textread(filename, '%1c%*[^\n]'));
        dataset{phaseID} = zeros( numImage, length(attributeNames) );
        for attID = 1:length(attributeNames)
            fprintf('\n\tattribute: %s ', attributeNames{attID});
            
            filename = strcat( 'imgList', phaseNames{phaseID}, 'Regression_', attributeNames{attID}, '.txt' );
            numImage = numel(textread(filename, '%1c%*[^\n]'));
            
            fid = fopen(filename, 'r');
            for lineID = 1:numImage
                if mod(lineID, 1000) == 0
                    fprintf('-%d-', lineID);
                end
                tline = fgets(fid);
                C = strsplit(tline, ' ');
                imgLabel = str2double(C{2});
                dataset{phaseID}(lineID, attID) = imgLabel;
            end
            fclose(fid);
        end
    end
    save attMat.mat
end

%% fitting training set
trainSet = dataset{1};
testSet = dataset{2};
valSet = dataset{3};

attributeNames = {'score', 'BalacingElements', 'ColorHarmony', 'Content', 'DoF', 'Light', 'MotionBlur', 'Object', 'Repetition', 'RuleOfThirds',...
        'Symmetry', 'VividColor'};

trainX = [trainSet(:,2:end) ];% trainSet(:,2:end).^2  ]; % trainSet(:,2:end)
trainy = trainSet(:,1);
a = sqrt(sum(trainX.^2, 1) );
trainX = trainX ./ repmat( a, size(trainX,1),1 );

testX = [testSet(:,2:end) ]; % testSet(:,2:end).^2]; % trainSet(:,2:end)
testy = testSet(:,1);
% a = sqrt(sum(testX.^2, 1) );
testX = testX ./ repmat( a, size(testX,1),1 );

valX = [valSet(:,2:end) ];%valSet(:,2:end).^2]; % trainSet(:,2:end)
valy = valSet(:,1);
% a = sqrt(sum(valX.^2, 1) );
valX = valX ./ repmat( a, size(valX,1),1 );

for lambda = 0:0.2:10
    fprintf('\nlambda=%.1f\n', lambda);
    beta = (trainX'*trainX + lambda*eye(size(trainX,2)))\trainX'*trainy;
    
    trainyhat = trainX*beta;        
    mae = mean( abs(trainyhat-trainy) );
    mse = mean(  (trainyhat-trainy).^2 );
    rmse = mean(  sqrt((trainyhat-trainy).^2) );
    rho = corr(trainyhat(:), trainy(:), 'Type', 'Spearman');   
    tau = corr(trainyhat(:), trainy(:), 'Type', 'Kendall');    
    %fprintf('on train set, mse=%.4f, mae=%.4f, rmse=%.4f, tau=%.4f, rho=%.4f\n', mse, mae, rmse, tau, rho);
    fprintf('on train set, mse=%.4f, mae=%.4f, tau=%.4f, rho=%.4f\n', mse, mae, tau, rho);
    
    valyhat = valX*beta;        
    mae = mean( abs(valyhat-valy) );
    mse = mean(  (valyhat-valy).^2 );
    rmse = mean(  sqrt((valyhat-valy).^2) );
    rho = corr(valyhat(:), valy(:), 'Type', 'Spearman');   
    tau = corr(valyhat(:), valy(:), 'Type', 'Kendall');
    %fprintf('on valid set, mse=%.4f, mae=%.4f, rmse=%.4f, tau=%.4f, rho=%.4f\n', mse, mae, rmse, tau, rho);
    fprintf('on valid set, mse=%.4f, mae=%.4f, tau=%.4f, rho=%.4f\n', mse, mae, tau, rho);
    
    testyhat = testX*beta;        
    mae = mean( abs(testyhat-testy) );
    mse = mean(  (testyhat-testy).^2 );
    rmse = mean(  sqrt((testyhat-testy).^2) );
    rho = corr(testyhat(:), testy(:), 'Type', 'Spearman');   
    tau = corr(testyhat(:), testy(:), 'Type', 'Kendall');
    %fprintf('on test set,  mse=%.4f, mae=%.4f, rmse=%.4f, tau=%.4f, rho=%.4f\n', mse, mae, rmse, tau, rho);
    fprintf('on test set,  mse=%.4f, mae=%.4f, tau=%.4f, rho=%.4f\n', mse, mae, tau, rho);
    
end

%%




